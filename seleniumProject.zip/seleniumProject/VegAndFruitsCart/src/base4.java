

	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.testng.annotations.AfterMethod;
	import org.testng.annotations.BeforeMethod;
	import org.testng.annotations.Test;

	import dev.failsafe.internal.util.Assert;


	public class base4 {
	    public WebDriver driver;

	    @BeforeMethod
	    public void setUp() {
	        // Podesavamo putanju do izvršne datoteke ChromeDriver
	        System.setProperty("webdriver.chrome.driver", "C:\\Users\\38160\\Downloads\\chromedriver.exe");

	        // Kreiramo novu instancu Chrome Drivera
	        driver = new ChromeDriver();

	        // Otvaramo website
	        driver.get("https://rahulshettyacademy.com/seleniumPractise/");
	        driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers");
	    }

	    @AfterMethod
	    public void tearDown() {
	        // Zatvaramo browser nakon sto se izvrsi metod
	       // driver.quit();
	    }
	@Test
	    public void testSearch() {
	        // pronadji element na stranici i ubaci upit
	        WebElement searchBox = driver.findElement(By.xpath("//input[@id='search-field']"));
	        searchBox.sendKeys("@");

	       //mozda da dodamo ovde wait

	        // Verifikujemo rezultate search-a
	        WebElement searchResults = driver.findElement(By.cssSelector("td.text-center"));
	        Assert.isTrue(searchResults.isDisplayed(), "No data");
	    }

	@Test
	public void test2Search() {
	    // pronadji element na stranici i ubaci upit
		WebElement searchBox = driver.findElement(By.xpath("//input[@id='search-field']"));
	    searchBox.sendKeys("Wh");



	    // Verifikujemo rezultate search-a
	    WebElement searchResults = driver.findElement(By.xpath("//td[text()='Wheat']"));
	    Assert.isTrue(searchResults.isDisplayed(), "Wheat");
	}
	
	@Test
	public void test3GoOnTheSecondPage()
	{
		//prelazimo na drugu stranu klikom na broj dva dugme
		driver.findElement(By.xpath("//span[contains(text(),'2')]")).click();
		WebElement searchResults = driver.findElement(By.xpath("//td[text()='Orange']"));
	    Assert.isTrue(searchResults.isDisplayed(), "Orange");
	    

	}


	}


