import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import dev.failsafe.internal.util.Assert;


public class base3 {
    public WebDriver driver;

    @BeforeMethod
    public void setUp() {
        // Podesavamo putanju do izvršne datoteke ChromeDriver
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\38160\\Downloads\\chromedriver.exe");

        // Kreiramo novu instancu Chrome Drivera
        driver = new ChromeDriver();

        // Otvaramo website
        driver.get("https://rahulshettyacademy.com/seleniumPractise/");
    }

    @AfterMethod
    public void tearDown() {
        // Zatvaramo browser nakon sto se izvrsi metod
      // driver.quit();
    }
@Test
    public void testSearchBox() {
        // pronadji element na stranici i ubaci upit
        WebElement searchBox = driver.findElement(By.cssSelector("input.search-keyword"));
        searchBox.sendKeys("3");

       //mozda da dodamo ovde wait

        // Verifikujemo rezultate search-a
        WebElement searchResults = driver.findElement(By.cssSelector("div.no-results"));
        Assert.isTrue(searchResults.isDisplayed(), "Sorry, no products matched your search!");
    }

@Test
public void test2SearchBox() {
    // pronadji element na stranici i ubaci upit
    WebElement searchBox = driver.findElement(By.cssSelector("input.search-keyword"));
    searchBox.sendKeys("Cuc");



    // Verifikujemo rezultate search-a
    WebElement searchResults = driver.findElement(By.cssSelector("div.product-image"));
    Assert.isTrue(searchResults.isDisplayed(), "Cucumber - 1 Kg");
}

}
