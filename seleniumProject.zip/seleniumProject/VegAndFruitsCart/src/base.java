import java.time.Duration;
import org.openqa.selenium.support.ui.Select;
import java.util.Arrays;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
public class base {
	//dohvatanje i stavljanje povrca u kolica
	//slucaj kada imamo povrce, tacan promo kod i Srbiju kao drzavu izabranu iz dropdown-a
	public static void main(String[] args) /* throws InterruptedException*/ {
		
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\38160\\Downloads\\chromedriver.exe"); //podesavanje chrome driver-a i dodavanje path-a 
	WebDriver driver = new ChromeDriver(); // kreiranje instance objekta drivera - chrome driver
	//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5)); //implicit wait zato sto mora da saceka da dodje na tu stranicu sa prve i da ucita sve stvari na stranici pa onda da upise promo code (implicit wait se primenjuje na ceo kod, globalna primena, mi smo ga deklarisali globalno, u glavnom programu)
	WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5)); //explicit wait
	String[] items = {"Cucumber", "Brocolli", "Beetroot", "Carrot"}; //kreiranje niza sa artiklima/proizvodima
	driver.get("https://rahulshettyacademy.com/seleniumPractise/"); //redirektovanje na url web app
	//Thread.sleep(3000);
	addItems(driver, items); //staticki metod - pozivanje
	driver.findElement(By.cssSelector("img[alt='Cart']")).click(); //klik na korpu (ikonicu)
	driver.findElement(By.xpath("//button[contains(text(),'PROCEED TO CHECKOUT')]")).click(); //klik na dugme proceed to checkout (nastavite na kasu)
	w.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input.promoCode"))); //explicit wait, cekamo da se ucita druga stranica
	driver.findElement(By.cssSelector("input.promoCode")).sendKeys("rahulshettyacademy"); //upisivanje promo koda kad je ok promo code
	driver.findElement(By.cssSelector("button.promoBtn")).click(); //klik na apply dugme
	
	
	//explicit wait - primenjujemo ga na neku konkretnu liniju koda
	
	w.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("span.promoInfo"))); // explicit wait, cekamo da kad kliknemo na apply da se prikaze tekst ispod polja
	System.out.println(driver.findElement(By.cssSelector("span.promoInfo")).getText()); //dohvati tekst ispod polja promo code-a
	driver.findElement(By.xpath("//button[contains(text(),'Place Order')]")).click(); //klik na place order dugme
	Select drpCountry = new Select(driver.findElement(By.xpath("//body/div[@id='root']/div[1]/div[1]/div[1]/div[1]/div[1]/select[1]")));
	drpCountry.selectByVisibleText("Serbia"); //dohvatimo Srbiju iz dropdown liste
	driver.findElement(By.cssSelector("input.chkAgree")).click(); //kliknemo na checkbox da se slazemo sa uslovima
	System.out.println(driver.findElement(By.cssSelector("input.chkAgree")).isSelected()); //istampamo u konzoli da li je zaista selektovan checkbox, trebalo bi da jeste
	driver.findElement(By.xpath("//button[contains(text(),'Proceed')]")).click();
	}
	
	//kreiranje statickog metoda addItems koji je tipa void (ne vraca nista)
	public static void addItems(WebDriver driver, String[] items) {
		int j=0;
		List<WebElement> products = driver.findElements(By.cssSelector("h4.product-name")); //svi proizvodi u prodavnici, dohvatamo ih i stavljamo ih u listu
		
		//kroz for petlju prolazimo kroz sve artikle u prodavnici
		for( int i = 0; i<products.size(); i++)
		{
			
			//Brocolli - 1 Kg
			// 1 - Brocolli, 2 - 1 Kg (objasnjenje split metode, sta je u prvom, a sta u drugom indeksu (prvi indeks je 0 jer indeksi pocinju od 0))
			//formatiranje da dobijemo pravo ime povrca/voca
			String[] name = products.get(i).getText().split("-");
			String formattedName = name[0].trim();
			
			//konvertovanje niza u listu niza (arrayList)
			List itemsList = Arrays.asList(items);
			

			//proverava da li ime koje je izvuceno prisutno u arrayList-i ili ne
			if(itemsList.contains(formattedName))
			{
				
				j++; 
				
				//klikni na Add to cart
				driver.findElements(By.xpath("//div[@class='product-action']/button")).get(i).click();
				
				//ide do kraja niza i kada dodje, izlazi iz njega
				if(j==items.length)
				{
					break;
				}
				
			}
		}
	}
}